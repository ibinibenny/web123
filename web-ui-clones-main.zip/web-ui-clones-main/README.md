## Web UI Clones
Website UI Clones using TailwindCSS ⚡⚡
- [x] <a href="https://whatsappwebui.netlify.app/" target="_blank">**WhatsApp Web**</a>
- [x] <a href="https://youtubewebui.netlify.app" target="_blank">**YouTube**</a>
- [x] <a href="https://instagramwebui.netlify.app" target="_blank">**Instagram**</a>
- [x] <a href="https://sololearnwebui.netlify.app" target="_blank">**Sololearn**</a>
- [x] <a href="https://flipmart.tech" target="_blank">**Flipkart**</a>
- [ ] Telegram
- [ ] Netflix

## Tech Stack
[![HTML](https://img.shields.io/badge/html5%20-%23E34F26.svg?&style=for-the-badge&logo=html5&logoColor=white)](https://github.com/jigar-sable/Web-UI-Clones/search?l=html)
![TailwindCSS](https://img.shields.io/badge/Tailwind_CSS-38B2AC?style=for-the-badge&logo=tailwind-css&logoColor=white)
[![JS](https://img.shields.io/badge/javascript%20-%23323330.svg?&style=for-the-badge&logo=javascript&logoColor=%23F7DF1E)](https://github.com/jigar-sable/Web-UI-Clones/search?l=javascript)
![node](https://img.shields.io/badge/Node.js-43853D?style=for-the-badge&logo=node.js&logoColor=white)
![jquery](https://img.shields.io/badge/jquery-%230769AD.svg?style=for-the-badge&logo=jquery&logoColor=white)
[![web](https://img.shields.io/badge/Netlify-00C7B7?style=for-the-badge&logo=netlify&logoColor=white)](https://youtubewebui.netlify.app)

<img src="https://user-images.githubusercontent.com/64949957/130316476-55a7b91e-801e-4698-8c87-31ae3cd1d1b8.png" height=300 width=500/>




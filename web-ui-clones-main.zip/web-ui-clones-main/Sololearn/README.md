## Sololearn UI Clone
Sololearn UI Clones using TailwindCSS ⚡

### <a href="https://Sololearnwebui.netlify.app" target="_blank">**Visit Now 🚀**</a>

## Tech Stack :
[![HTML](https://img.shields.io/badge/html5%20-%23E34F26.svg?&style=for-the-badge&logo=html5&logoColor=white)](https://github.com/jigar-sable/Web-UI-Clones/search?l=html)
![TailwindCSS](https://img.shields.io/badge/Tailwind_CSS-38B2AC?style=for-the-badge&logo=tailwind-css&logoColor=white)
[![JS](https://img.shields.io/badge/javascript%20-%23323330.svg?&style=for-the-badge&logo=javascript&logoColor=%23F7DF1E)](https://github.com/jigar-sable/Web-UI-Clones/search?l=javascript)
![node](https://img.shields.io/badge/Node.js-43853D?style=for-the-badge&logo=node.js&logoColor=white)
[![web](https://img.shields.io/badge/Netlify-00C7B7?style=for-the-badge&logo=netlify&logoColor=white)](https://instagramwebui.netlify.app)

## Sneak Peek of Site 🙈 :
![sololearn](https://user-images.githubusercontent.com/64949957/130730792-0a2243c5-5e20-4216-9631-5e37646a3ee3.PNG)


[![forthebadge](https://forthebadge.com/images/badges/built-with-love.svg)](https://forthebadge.com)


